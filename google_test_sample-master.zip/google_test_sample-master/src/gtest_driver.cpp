/*
 * gtest_driver.cpp
 *
 *  Created on: Aug 30, 2018
 *      Author: yardmaster
 */

#include <gtest/gtest.h>

int main(int argc, char **argv) {
	::testing::InitGoogleTest(&argc, argv);

	return RUN_ALL_TESTS();
}


