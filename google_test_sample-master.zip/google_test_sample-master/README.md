This is just a simple example of a running google test project
